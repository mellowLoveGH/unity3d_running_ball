﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;


public class PlayerController : MonoBehaviour
{

	public float m_speed = 5f;
	public Text countText;
	public Text winText;

	private Rigidbody m_rigidbody;
	//private CharacterController m_character;
	private int count;

	private bool flag = true;

	// Use this for initialization
	void Start ()
	{
		m_rigidbody = GetComponent<Rigidbody> ();
		//m_character = GetComponent<CharacterController> ();
		count = 0;
		SetCount ();
		winText.text = "";
	}
	
	// Update is called once per frame
	void Update ()
	{
		MoveControlByTranslate ();
		//MoveControlByTranslateGetAxis();
		//MoveControlByVelocity();
		//MoveControlByAddForce ();
		//MoveControlBySimpleMove();
		//MoveControlByMove ();
	}

	//transform one
	void MoveControlByTranslate ()
	{
		if (Input.GetKey (KeyCode.W) | Input.GetKey (KeyCode.UpArrow)) { //前
			this.transform.Translate (Vector3.forward * m_speed * Time.deltaTime);
		}
		if (Input.GetKey (KeyCode.S) | Input.GetKey (KeyCode.DownArrow)) { //后
			this.transform.Translate (Vector3.forward * -m_speed * Time.deltaTime);
		}
		if (Input.GetKey (KeyCode.A) | Input.GetKey (KeyCode.LeftArrow)) { //左
			this.transform.Translate (Vector3.right * -m_speed * Time.deltaTime);
		}
		if (Input.GetKey (KeyCode.D) | Input.GetKey (KeyCode.RightArrow)) { //右
			this.transform.Translate (Vector3.right * m_speed * Time.deltaTime);
		}

		if(Input.GetKey (KeyCode.Space) && flag){
			this.transform.Translate (Vector3.up * m_speed * 11 * Time.deltaTime);
			flag = false;
		}

		int y = (int)(this.transform.localPosition.y + 0.5);

		Debug.Log (y.ToString());
	}

	void OnCollisionEnter(Collision collision){
		flag = true;
	}


	//transform two
	void MoveControlByTranslateGetAxis ()
	{
		float horizontal = Input.GetAxis ("Horizontal"); //A D 左右
		float vertical = Input.GetAxis ("Vertical"); //W S 上 下

		transform.Translate (Vector3.forward * vertical * m_speed * Time.deltaTime);//W S 上 下
		transform.Translate (Vector3.right * horizontal * m_speed * Time.deltaTime);//A D 左右
	}

	//rigidbody one
	void MoveControlByVelocity ()
	{
		float horizontal = Input.GetAxis ("Horizontal"); //A D 左右
		float vertical = Input.GetAxis ("Vertical"); //W S 上 下

		if (Input.GetKey (KeyCode.W) | Input.GetKey (KeyCode.S)) {
			m_rigidbody.velocity = Vector3.forward * vertical * m_speed;
		}
		if (Input.GetKey (KeyCode.A) | Input.GetKey (KeyCode.D)) {
			m_rigidbody.velocity = Vector3.right * horizontal * m_speed;
		}   


	}

	//rigidbody two
	void MoveControlByAddForce ()
	{
		float horizontal = Input.GetAxis ("Horizontal"); //A D 左右
		float vertical = Input.GetAxis ("Vertical"); //W S 上 下

		m_rigidbody.AddForce (Vector3.forward * vertical * m_speed);
		m_rigidbody.AddForce (Vector3.right * horizontal * m_speed);  

	}

	//CharacterController one
	void MoveControlBySimpleMove ()
	{
		float horizontal = Input.GetAxis ("Horizontal"); //A D 左右
		float vertical = Input.GetAxis ("Vertical"); //W S 上 下

		//m_character.SimpleMove (transform.forward * vertical * m_speed); 
	}


	//CharacterController two
	void MoveControlByMove ()
	{
		float horizontal = Input.GetAxis ("Horizontal"); //A D 左右
		float vertical = Input.GetAxis ("Vertical"); //W S 上 下
		float moveY = 0; 
		float m_gravity = 10f;
		moveY -= m_gravity * Time.deltaTime;//重力

		//m_character.Move (new Vector3 (horizontal, moveY, vertical) * m_speed * Time.deltaTime);
	}

	//
	void OnTriggerEnter(Collider other){
		if(other.gameObject.CompareTag("pick up")){
			other.gameObject.SetActive (false);
		}
		count++;
		SetCount ();
	}

	//
	void SetCount(){
		countText.text = "count : " + count.ToString();
		if(count >= 12){
			winText.text = "you win";
		}
	}

}
